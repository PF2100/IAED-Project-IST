#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

/* Constantes do numero maximo de caracteres do ID, do pais , da cidade , dos aeroportos e dos voos , respetivamente.*/

#define MAX_CODE 7
#define MAXIDX 4
#define MAXCTRY 31
#define MAXCITY 51
#define MAXAIR 40
#define MAXFLT 30000

typedef struct
{
    int day, month, year;
} date;

date currentDate = {1, 1, 2022};

int n_ports = 0; /* Number of airports in Aero*/
int totalFlights = 0;

typedef struct
{
    int hour, minute;
} time;

typedef struct
{
    char code[MAX_CODE], idDeparture[MAXIDX], idArrival[MAXIDX];
    date departureDate;
    time departureTime;
    time durationTime;
} Flights;

typedef struct
{
    char id[MAXIDX];
    char country[MAXCTRY];
    char city[MAXCITY];
    int nflights;
} Airport;

Airport Aero[MAXAIR]; /* Vector of Airport stuctures*/
Flights Flts[MAXFLT];
Flights tempFlt[MAXFLT];

void command_a();
void command_l();
void command_v();
void command_p();
void command_t();

void insertSortA();
int airportExists(char id[]);
int validateCode(char code[]);
int validateFlightCodeNumber(char code[]);
int validateFlight(char code[], int yy, int mm, int dd);
int validateFlightAirports(char idDeparture[], char idArrival[]);
int validateDate(int dd, int mm, int yy);
int validateDuration(int durHour, int durMin);
int validateCapacity();
void saveFlightIDs(char code[], char idDeparture[], char idArrival[]);
date saveDate(int dd, int mm, int yy, date dates);
void saveTime(int hr, int min, int durHour, int durMin);
void sortFlights(Flights tempFlt[],int idx);
int compareDates( date depDate , time depTime , date keyDate , time keyTime);





int main()
{
    char command;
    int stop = 1;
    while (stop)
    {
        command = getchar(); /*First character of every input line will determine wich case will happen */
        switch (command)
        {
        case 'q':
            stop = 0;
            break;
        case 'a':
            command_a();
            break;
        case 'l':
            command_l();
            break;
        case 'v':
            command_v();
            break;
        case 'p':
            command_p();
            break;
        case 'c':
            break;
        case 't':
            command_t();
            break;
        default:
            break;
        }
    }
    return 0;
}

void command_a()
{
    int count;
    char id[MAXIDX], country[MAXCTRY], city[MAXCITY];
    scanf("%s %s %[^\n]", id, country, city); /* Temporary ID , country , and city vectors */
    for (count = 0; count < MAXIDX - 1; count++)
    { /*For the amount of characters in id , if the character is not an upper case letter than print the message "invalid airport ID\n" */
        if ((id[count] < 'A' || id[count] > 'Z'))
        {
            printf("invalid airport ID\n");
            return;
        }
    }

    for (count = 0; count < n_ports; count++)
    { /*For n_ports , if there is another airport with the same id already , print the message " duplicate airport "*/
        if (strcmp(Aero[count].id, id) == 0)
        {
            printf("duplicate airport\n");
            return;
        }
    }

    if (n_ports < MAXAIR)
    { /* If the number of airports is smaller than the size of Aero then carry on , otherwise print the message "too many airports" */

        strcpy(Aero[n_ports].id, id);
        strcpy(Aero[n_ports].country, country);
        strcpy(Aero[n_ports].city, city);
        Aero[n_ports].nflights = 0;
        printf("airport %s\n", Aero[n_ports].id);
        n_ports++;
        if (n_ports > 1)
        { /* Sorting the vector of Airport structures after adding a new airport to it */
            insertSortA();
        }
    }
    else
    {
        printf("too many airports\n");
    }
}

void insertSortA()
{
    int mark, count;
    Airport Key;
    for (mark = 1; mark < n_ports; mark++)
    {
        Key = Aero[mark];
        count = mark - 1;
        while (count >= 0 && strcmp(Aero[count].id, Key.id) > 0)
        {
            Aero[count + 1] = Aero[count];
            count = count - 1;
        }
        Aero[count + 1] = Key;
    }
}

void command_l()
{
    char c, id[MAXIDX];
    int count = 0, id_pos;
    c = getchar(); /* c is the first charachter after the command */
    while (count < n_ports && c == '\n')
    { /* If c is not a newline character , then for the amount of airports in Aero print the members of each structure */
        printf("%s %s %s %d\n", Aero[count].id, Aero[count].city, Aero[count].country, Aero[count].nflights);
        count++;
    }
    while (c != '\n')
    { /* if c is a newline */
        scanf("%s", id);  /* id_pos is the value returned by the function compareID which can be either -1 or a number between 0 and MAXAIR - 1 */
        if ((id_pos = airportExists(id)) == -1)
        {
            printf("%s: no such airport ID\n", id);
            c = getchar();
        }
        else
        {
            printf("%s %s %s %d\n", Aero[id_pos].id, Aero[id_pos].city, Aero[id_pos].country, Aero[id_pos].nflights);
            c = getchar();
        }
    }
}

int airportExists(char id[])
{
    int count = 0;
    while (count < n_ports)
    { /* For the number of airports in the Aero vector , if the input of the fuction corresponds to the ID of an airplane in the vector Aero , return the index of that same airport in the vector */
        if (strcmp(id, Aero[count].id) == 0)
        {
            return count;
        }
        count++;
    }
    return -1; /* Otherwise return the value of -1 */
}

void command_v()
{
    date dates;
    char code[MAX_CODE], idDeparture[MAXIDX], idArrival[MAXIDX], c;
    int count = 0, idx ,yy, mm, dd, hr, min, durHour, durMin, Cap;
    if ((c = getchar()) != '\n')
    {
        scanf("%s %s %s", code, idDeparture, idArrival);
        scanf("%d-%d-%d %d:%d", &dd, &mm, &yy, &hr, &min);
        scanf("%d:%d", &durHour, &durMin);
        if (validateCode(code) == 0 || validateFlight(code, yy, mm, dd) == -1 || (idx = validateFlightAirports(idDeparture, idArrival))== -1 || validateDate(dd, mm, yy) == 0 || (validateDuration(durHour, durMin) == -1 || (Cap = validateCapacity()) == -1))
        {

            return;
        }
        saveFlightIDs(code, idDeparture, idArrival);
        Flts[totalFlights].departureDate = saveDate(dd, mm, yy, dates);
        saveTime(hr, min, durHour, durMin);
        Aero[idx].nflights++;
        totalFlights++;
        return;
    }
    while (count < totalFlights)
    {
        printf("%s %s %s ", Flts[count].code, Flts[count].idDeparture, Flts[count].idArrival);

        printf("%02d-%02d-%02d %02d:%02d\n", Flts[count].departureDate.day, Flts[count].departureDate.month,
               Flts[count].departureDate.year, Flts[count].departureTime.hour, Flts[count].departureTime.minute);
        count++;
    }
    return;
}

int validateFlightCodeNumber(char code[])
{
    int i = 2;
    int nonZero = 0;
    while (code[i] != '\0')
    {
        if (code[i] == '0' && nonZero == 0)
        {
            return 0;
        }
        else if (code[i] >= '0' && code[i] <= '9')
        {
            nonZero = 1;
        }
        i++;
    }
    return 1;
}

int validateCode(char code[])
{
    if (isupper(code[0]) && isupper(code[1]) && validateFlightCodeNumber(code))
    {
        return 1;
    }
    printf("invalid flight code\n");
    return 0;
}

int validateFlight(char code[], int yy, int mm, int dd)
{
    int count;
    for (count = 0; count < totalFlights; count++)
    {
        if (strcmp(code, Flts[count].code) == 0)
        {
            if (yy == Flts[count].departureDate.year && mm == Flts[count].departureDate.month && dd == Flts[count].departureDate.day)
            {
                printf("flight already exists\n");
                return -1;
            }
        }
    }
    return 0;
}

int validateFlightAirports(char idDeparture[], char idArrival[])
{
    int id;
    if ((id = airportExists(idDeparture)) == -1)
    {
        printf("%s: no such airport ID\n", idDeparture);
        return -1;
    }
    else if ( airportExists(idArrival)  == -1)
    {
        printf("%s: no such airport ID\n", idArrival);
        return -1;
    }
    return id ;
}

int validateDate(int dd, int mm, int yy)
{
    if (yy < currentDate.year || (yy == currentDate.year && mm < currentDate.month) || (yy > currentDate.year && mm > currentDate.month))
    {
        printf("invalid date\n");
        return 0;
    }
    else if (yy == currentDate.year && mm == currentDate.month && dd < currentDate.day)
    {
        printf("invalid date\n");
        return 0;
    }
    else if (yy > currentDate.year && mm == currentDate.month && dd > currentDate.day)
    {
        printf("invalid date\n");
        return 0;
    }
    else if (yy >= 2024)
    {
        printf("invalid date\n");
        return 0;
    }
    return 1;
}

int validateDuration(int durHour, int durMin)
{
    if (durHour == 12 && durMin > 0)
    {
        printf("invalid duration\n");
        return -1;
    }
    return 0;
}

int validateCapacity()
{
    int Type, Cap;
    Type = scanf("%d", &Cap);
    if (Type == 0 || Cap < 10 || Cap > 100)
    {
        printf("invalid capacity\n");
        return -1;
    }
    return Cap;
}

void saveFlightIDs(char code[], char idDeparture[], char idArrival[])
{
    strcpy(Flts[totalFlights].code, code);
    strcpy(Flts[totalFlights].idDeparture, idDeparture);
    strcpy(Flts[totalFlights].idArrival, idArrival);
    return;
}
date saveDate(int dd, int mm, int yy, date dates)
{
    dates.year = yy;
    dates.month = mm;
    dates.day = dd;
    return dates;
}

void saveTime(int hr, int min, int durHour, int durMin)
{
    Flts[totalFlights].departureTime.hour = hr;
    Flts[totalFlights].departureTime.minute = min;
    Flts[totalFlights].durationTime.hour = durHour;
    Flts[totalFlights].durationTime.minute = durMin;
    return;
}







void command_p() {
    Flights tempFlt[MAXFLT]; 
    char airportID[MAXIDX];
    int j,idx , nPortFlights,count;
    scanf("%s",airportID);
    if ( (idx = airportExists(airportID)) == -1 ) {
        printf("%s: no such airport ID\n",airportID);
        return;
    }
    nPortFlights = Aero[idx].nflights; /*troca  o tamanho*/
    for ( count = 0 , j = 0; (j < nPortFlights) && count < totalFlights ; count++ ) {
        if ( strcmp(airportID,Flts[count].idDeparture) == 0 ) {
            tempFlt[j] = Flts[count];
            j++;
        }
    }
    sortFlights(tempFlt,j);
    for ( count = 0 ; count < nPortFlights ; count++ ) {
        printf("%s %s %02d-%02d-%d %02d:%02d\n",tempFlt[count].code,tempFlt[count].idArrival,tempFlt[count].departureDate.day, tempFlt[count].departureDate.month,
               tempFlt[count].departureDate.year, tempFlt[count].departureTime.hour, tempFlt[count].departureTime.minute);
    }
    return;
    
}





void sortFlights( Flights tempFlt[],int idx) {
    int mark, count;
    Flights key;
    for (mark = 1; mark < idx; mark++)
    {
        key = tempFlt[mark];
        count = mark - 1;
        while (count >= 0 && compareDates(tempFlt[count].departureDate,tempFlt[count].departureTime,key.departureDate,key.departureTime) == 0)
        {
            tempFlt[count + 1] = tempFlt[count];
            count = count - 1;
        }
        tempFlt[count + 1] = key;
    }
}

int compareDates(date fltsDate , time fltsTime , date keyDate , time keyTime ) {
    if (keyDate.year > fltsDate.year || (keyDate.year == fltsDate.year && keyDate.month > fltsDate.month) 
             || (keyDate.year == fltsDate.year && keyDate.month == fltsDate.month && keyDate.day > fltsDate.day)) {
        return 1;
    }
    else if ((keyDate.year == fltsDate.year) && (keyDate.month == fltsDate.month) && (keyDate.day == fltsDate.day)) {
        if (keyTime.hour > fltsTime.hour ||(keyTime.hour == fltsTime.hour && keyTime.minute > fltsTime.minute)) {
            return 1;
        }
        else {return 0;}
    }
    return 0;
}













void command_t() {
    date dates;
    int dd, mm, yy;
    scanf("%d-%d-%d", &dd, &mm, &yy);
    if (validateDate(dd, mm, yy) == 0){
        return;
    }
    currentDate = saveDate(dd, mm, yy, dates);
    printf("%02d-%02d-%02d\n", currentDate.day, currentDate.month, currentDate.year);
}